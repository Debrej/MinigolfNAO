import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;



import java.awt.image.BufferedImage;



public class Image
{
    
    public static void saveImage(String imageUrl, String destinationFile) throws IOException {
        URL url = new URL(imageUrl);
        InputStream is = url.openStream();
        OutputStream os = new FileOutputStream(destinationFile);

        byte[] b = new byte[2048];
        int length;

        while ((length = is.read(b)) != -1) {
            os.write(b, 0, length);
            //System.out.println("debug");
        }

        is.close();
        os.close();
    }

public static void main(String args[]) throws IOException, InterruptedException{
    
     
      while(true){
      
          String imageUrl = "http://172.18.82.226:8080/photo.jpg";
          String destinationFile = "rsrc/image.jpg";
            
          saveImage(imageUrl, destinationFile);
          
          File file= new File("rsrc/image.jpg");
          BufferedImage image = ImageIO.read(file);
          //file.close();
          // Getting pixel color by position x and y
          
          int nbBall=0;
          int nbxBall = 0;
          int nbyBall = 0;
          int nbFront = 0;
          int nbxFront = 0;
          int nbyFront = 0;
          int nbBack = 0;
          int nbxBack = 0;
          int nbyBack = 0;
          int nbHole = 0;
          int nbxHole = 0;
          int nbyHole = 0;
          
          for(int i = 0; i < image.getWidth() ; i++){
              for(int j = 0; j < image.getHeight(); j++){
                  
                  int clr=  image.getRGB(i,j); 
                  int  red   = (clr & 0x00ff0000) >> 16;
                  int  green = (clr & 0x0000ff00) >> 8;
                  int  blue  =  clr & 0x000000ff;
                  
                  if(red>160 && green < 70 && blue < 70) {
                      nbBall++;
                      nbxBall += i;
                      nbyBall += j;
                      image.setRGB(i, j,0xffaa00 );
                  }
                  
                  if(red<160 && green > 170 && blue > 240) {
                      nbFront++;
                      nbxFront += i;
                      nbyFront += j;
                      image.setRGB(i, j, 0xff0000);
                  }
                  if(red>220 && green < 200 && blue > 220) {
                      nbBack++;
                      nbxBack += i;
                      nbyBack += j;
                      image.setRGB(i, j, 0xc71585);
                  }
                  if(red<180 && green > 200 && blue < 200) {
                      nbHole++;
                      nbxHole += i;
                      nbyHole += j;
                      image.setRGB(i, j, 0xc233424);
                  }
                  
              } 
              
          }
          
          System.out.println("nb : " + nbBall + " ball :" + nbxBall/(nbBall+1) + "x" + nbyBall/(nbBall+1));
          System.out.println("nb : " + nbFront + " front :" + nbxFront/(nbFront+1) + "x" + nbyFront/(nbFront+1));
          System.out.println("nb : " + nbBack + " back :" + nbxBack/(nbBack+1) + "x" + nbyBack/(nbBack+1));
          System.out.println("nb : " + nbHole + " hole :" + nbxHole/(nbHole+1) + "x" + nbyHole/(nbHole+1));
        
        
          JLabel label = new JLabel(new ImageIcon(image));
          JPanel panel = new JPanel();
          panel.add(label);
          JFrame frame = new JFrame();
          frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          panel.add(label);
          frame.add(panel);
          frame.setSize(1280, 720);
          frame.setVisible(true);
          
          Thread.sleep(1000);

        }
    }
}
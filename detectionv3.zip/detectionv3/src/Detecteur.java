import java.io.*;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.*;

import java.awt.image.BufferedImage;

public class Detecteur extends JPanel
{
	static int nbBall=0;
	static  int nbxBall = 0;
	static  int nbyBall = 0;
	static  int nbFront = 0;
	static  int nbxFront = 0;
	static  int nbyFront = 0;
	static  int nbBack = 0;
	static  int nbxBack = 0;
	static  int nbyBack = 0;
	static  int nbHole = 0;
	static  int nbxHole = 0;
	static  int nbyHole = 0;
	
	public static void saveImage(String imageUrl, String destinationFile) throws IOException {
        URL url = new URL(imageUrl);
        InputStream is = url.openStream();
        OutputStream os = new FileOutputStream(destinationFile);

        byte[] b = new byte[2048];
        int length;

        while ((length = is.read(b)) != -1) {
            os.write(b, 0, length);
            System.out.println("debug");
        }

        is.close();
        os.close();
    }
	
	public static double angle (double x1, double y1, double x2, double y2) {
	    double xdiff = x1 - x2;
	    double ydiff = y1 - y2;
	    //double tan = xdiff / ydiff;
	    double atan = Math.atan2(ydiff, xdiff);
	    return atan;
	}
	/*public static void tracerSegment (int x1,int x2,int y1,int y2, BufferedImage image){
	    boolean steep = (Math.abs(y2 - y1) > Math.abs(x2 - x1));
	    if(steep)
	    {
	        //swap(x1, y1);
	        int temp=x1;
	        x1=y1;
	        y1=temp;
	        //swap(x2, y2);
	        int temp2=x2;
	        x2=y2;
	        y2=temp2;
	    }

	    if(x1 > x2)
	    {
	        //swap(x1, x2);
	        int temp=x1;
	        x1=x2;
	        x2=temp;

	        //swap(y1, y2);
	        int temp2=y1;
	        y1=y2;
	        y2=temp2;
	    }

	    float dx = x2 - x1;
	    float dy = Math.abs(y2 - y1);

	    float error = (float) (dx / 2.0);

	    int ystep;

	    if (y1 < y2){
	        ystep = 1;
	    } else {
	        ystep = - 1;
	    }

	    int y = y1;

	    for(int x = x1; x <= x2; x++)
	    {
	        if(steep)
	        {
	            //g.allumerPixel(y,x);
	        	System.out.println("x: " + x + ", y: " + y);
	            image.setRGB(x,y,0xFF1493);
	        }
	        else
	        {
	            //g.allumerPixel(x,y);
	        	
	            image.setRGB(x,y,0xFF1493);
	        }

	        error -= dy;

	        if(error < 0)
	        {
	            y += ystep;
	            error += dx;
	        }
	    }
	}*/
	
protected void painComponent(Graphics graphics) {
	System.out.println("Dessin");
	graphics.setColor(Color.PINK);
	graphics.drawLine(nbxHole/nbHole, nbyHole/nbHole, nbxBall/nbBall, nbyBall/nbBall);
}
	
  public static void main(String args[]) {
      BufferedImage image = null;
	  while(true) {
		  int nbBall=0;
			nbxBall = 0;
			nbyBall = 0;
			nbFront = 0;
			nbxFront = 0;
			nbyFront = 0;
			nbBack = 0;
			nbxBack = 0;
			nbyBack = 0;
			nbHole = 0;
			nbxHole = 0;
			nbyHole = 0;
		  String imageUrl = "http://172.18.82.226:8080/photo.jpg";
	      String destinationFile = "rsrc/image.jpg";
	        
	      try {
			saveImage(imageUrl, destinationFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      
	      File file= new File("rsrc/image.jpg");

		try {
			image = ImageIO.read(file);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  
	  //File file= new File("rsrc/photo.jpg");
	  //BufferedImage image = ImageIO.read(file);
	  // Getting pixel color by position x and y
	
	
	  for(int i = 0; i < image.getWidth() ; i++){
	          for(int j = 0; j < image.getHeight(); j++){
	                
	                  int clr=  image.getRGB(i,j);
	                  int  red   = (clr & 0x00ff0000) >> 16;
	                  int  green = (clr & 0x0000ff00) >> 8;
	                  int  blue  =  clr & 0x000000ff;
	                
	                  if(red>150 && green < 70 && blue < 70) {
	                          nbBall++;
	                          nbxBall += i;
	                          nbyBall += j;
	                          image.setRGB(i, j,0xffaa00 );
	                  }
	                
	                  if(red<160 && green > 220 && blue > 240) {
	                          nbFront++;
	                          nbxFront += i;
	                          nbyFront += j;
	                          image.setRGB(i, j, 0xff0000);
	                  }
	                  if(red>240 && green < 220 && blue > 240) {
	                          nbBack++;
	                          nbxBack += i;
	                          nbyBack += j;
	                          image.setRGB(i, j, 0xc71585);
	                  }
	                  if(red<180 && green > 200 && blue < 200) {
	                          nbHole++;
	                          nbxHole += i;
	                          nbyHole += j;
	                          image.setRGB(i, j, 0xc233424);
	                  }
	                
	          }
	        
	  }
	
	  System.out.println("nb : " + nbBall + " ball :" + nbxBall/nbBall +
	"x" + nbyBall/nbBall);
	  System.out.println("nb : " + nbFront + " front :" + nbxFront/nbFront
	+ "x" + nbyFront/nbFront);
	  System.out.println("nb : " + nbBack + " back :" + nbxBack/nbBack +
	"x" + nbyBack/nbBack);
	  System.out.println("nb : " + nbHole + " hole :" + nbxHole/nbHole +
	"x" + nbyHole/nbHole);
	  
	  Point ball = new Point(nbxBall/nbBall,nbyBall/nbBall);
	  Point hole = new Point(nbxHole/nbHole,nbyHole/nbHole);
	  Point front = new Point(nbxFront/nbFront, nbyFront/nbFront);
	  Point back = new Point(nbxBack/nbBack,nbyBack/nbBack);
	  Point nao = new Point((int)(front.getX()+back.getX())/2,(int)(front.getY()+back.getY())/2);
	  //Point ball = new Point(nbxBall/nbBall,nbyBall/nbBall);
	  
	  /* """"TRACAGE DE LA PERPENDICULAIRE 1 ######################*/
	  double slope = ((double)(ball.getY()-hole.getY())/(double)(ball.getX()/hole.getX()));
	  slope = -1.0/slope;
	  
	  
	  //Point mid = new Point((int)(ball.getX()+hole.getX())/2,(int)(ball.getY()+hole.getY())/2);
	  
	  double b = -slope * ball.getX() + ball.getY();
	  
	  Point p4 = new Point((int)ball.getX()+400,(int)(slope*(ball.getX()+400)+b));
	  
	  
	  
	  Graphics2D g2d =image.createGraphics();
	  g2d.setColor(Color.BLACK);
	  //g2d.drawLine(nbxHole/nbHole, nbyHole/nbHole, nbxBall/nbBall, nbyBall/nbBall);
	  
	  
	  if(nao.getX()<ball.getX()) {
		  p4.setLocation(-p4.getX(),p4.getY());
	  }
	  
	  //###########TRACE DE LA PERPENDICULAIRE ROBOT####################"
	  Point pDroite = new Point((int)nao.getX(),(int)(slope*Math.max(nao.getX(),ball.getX())-Math.min(nao.getX(),ball.getX())));
	  
	  if(nao.getY()>pDroite.getY()) {
		  pDroite.setLocation(pDroite.getX(),-pDroite.getY());
	  }
	  
	  
	  
	  g2d.drawLine((int)hole.getX(), (int)hole.getY(), (int)ball.getX(), (int)ball.getY());
	  g2d.drawLine((int)ball.getX(), (int)ball.getY(), (int)p4.getX(), (int)p4.getY());
	  g2d.drawLine((int)nao.getX(), (int)nao.getY(), (int)pDroite.getX(), (int)pDroite.getY());
	
	  JLabel label = new JLabel(new ImageIcon(image));
	  JPanel panel = new JPanel();
	  panel.add(label);
	  JFrame frame = new JFrame();
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  panel.add(label);
	  frame.add(panel);
	  frame.setSize(1280, 720);
	  frame.setVisible(true);
	  
	  try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  }
  
  }
}